import { Examen } from './examen';
import { Consulta } from './consulta';

export class ConsultaListaExamenDTO{
    consulta: Consulta;
    listExamen: Examen[];
}